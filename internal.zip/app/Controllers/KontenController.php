<?php

namespace App\Controllers;

use App\Controllers\BaseController;
use App\Models\BisnisModel;
use App\Models\DetailKontenModel;
use App\Models\KontenModel;
use App\Models\KontenSosmedModel;
use App\Models\SosmedModel;
use App\Models\UserSosmedModel;
use CodeIgniter\HTTP\ResponseInterface;

class KontenController extends BaseController
{

    protected $sosmedModel;
    protected $bisnisModel;
    protected $kontenModel;
    protected $detailKontenModel;
    protected $kontenSosmedModel;
    protected $userSosmedModel;

    public function __construct()
    {
        $this->sosmedModel = new SosmedModel();
        $this->bisnisModel = new BisnisModel();
        $this->kontenModel = new KontenModel();
        $this->detailKontenModel = new DetailKontenModel();
        $this->kontenSosmedModel = new KontenSosmedModel();
        $this->userSosmedModel = new UserSosmedModel();
    }

    public function index($id_bisnis = null)
    {
        $id_user = session()->get('id_user');

        $idSosmedUser = $this->userSosmedModel->getSosmedIdsByUser($id_user);

        $allBisnis = $this->bisnisModel->findAll();
        $platformParam = $this->request->getGet('platform');
        $selectedPlatforms = $platformParam ? explode(',', $platformParam) : [];

        $allKonten = $id_bisnis
            ? $this->kontenModel->getKontenWithPlatforms($id_bisnis)
            : $this->kontenModel->getKontenWithPlatforms();

        // Hanya tampilkan konten milik akun sosmed user login
        if (session()->get('role') !== 'admin') {
            $allKonten = array_filter($allKonten, function ($konten) use ($idSosmedUser) {
                $kontenSosmedIds = explode(',', $konten['id_sosmed'] ?? '');
                foreach ($kontenSosmedIds as $id) {
                    if (in_array($id, $idSosmedUser)) {
                        return true;
                    }
                }
                return false;
            });
        }

        if (!empty($selectedPlatforms)) {
            $allKonten = array_filter($allKonten, function ($konten) use ($selectedPlatforms) {
                $kontenPlatforms = explode(',', $konten['platforms'] ?? '');
                foreach ($selectedPlatforms as $plat) {
                    if (in_array($plat, $kontenPlatforms)) {
                        return true;
                    }
                }
                return false;
            });
        }

        foreach ($allKonten as &$konten) {
            $konten['platforms'] = explode(',', $konten['platforms'] ?? '');
            $konten['akun_platform'] = explode(',', $konten['akun_platform'] ?? '');
        }

        $data = [
            'allKonten'      => $allKonten,
            'allBisnis'      => $allBisnis,
            'id_bisnis'      => $id_bisnis,
            'platformFilter' => $platformParam
        ];

        return view('pages/konten_sosmed/index', $data);
    }

    public function tambah()
    {
        $allBisnis = $this->bisnisModel->findAll();
        $data = [
            'allBisnis' => $allBisnis,
        ];
        return view('pages/konten_sosmed/tambah', $data);
    }

    public function simpan()
    {
        // Ambil data dari form
        $data['judul'] = $this->request->getPost('judul');
        $data['caption'] = $this->request->getPost('caption');

        // Tangani upload cover
        // Validasi file cover secara manual sebelum save model
        $cover = $this->request->getFile('cover');
        if ($cover && $cover->isValid() && !$cover->hasMoved()) {
            // Cek tipe file dan ukuran manual
            if (!in_array($cover->getExtension(), ['jpg', 'jpeg', 'png', 'gif'])) {
                return redirect()->back()->with('error', 'Format file cover tidak didukung')->withInput();
            }
            if ($cover->getSize() > 2048 * 1024) {
                return redirect()->back()->with('error', 'Ukuran file cover maksimal 2MB')->withInput();
            }
            $nama_cover = $cover->getRandomName();
            $cover->move('assets/sosmed/cover', $nama_cover);
            $data['cover'] = $nama_cover;
        }

        // dd($data);

        if (!$this->kontenModel->save($data)) {
            // Ambil error validasi
            $errors = $this->kontenModel->errors();

            return redirect()->back()
                ->with('error', 'Gagal menyimpan konten.')
                ->with('validation', $errors)
                ->withInput();
        }

        $id_konten = $this->kontenModel->insertID();

        // Simpan ke kontenSosmedModel
        $id_sosmed_list = $this->request->getPost('id_sosmed');
        $tgl_upload = $this->request->getPost('tgl_upload');

        if (!empty($id_sosmed_list)) {
            foreach ($id_sosmed_list as $id_sosmed) {
                $this->kontenSosmedModel->save([
                    'id_sosmed' => $id_sosmed,
                    'id_konten' => $id_konten,
                    'tgl_upload' => $tgl_upload
                ]);
            }
        }

        $konten_files = $this->request->getFileMultiple('konten_file');
        // dd($konten_files);

        if ($konten_files) {
            foreach ($konten_files as $konten_file) {
                // Validasi manual
                if (!$konten_file->isValid()) {
                    return redirect()->back()
                        ->with('error', 'Salah satu file tidak valid.')
                        ->withInput();
                }

                // Validasi ekstensi
                $allowedTypes = ['image/jpeg', 'image/png', 'image/webp', 'video/mp4', 'video/mpeg'];
                if (!in_array($konten_file->getClientMimeType(), $allowedTypes)) {
                    return redirect()->back()
                        ->with('error', 'Tipe file tidak didukung (hanya gambar/video).')
                        ->withInput();
                }

                // Validasi ukuran (misal maksimal 5MB)
                if ($konten_file->getSize() > 5 * 1024 * 1024) {
                    return redirect()->back()
                        ->with('error', 'Ukuran file terlalu besar. Maksimal 5MB.')
                        ->withInput();
                }

                // Tentukan tipe media berdasarkan MIME type
                $tipe_media = (strpos($konten_file->getClientMimeType(), 'image') !== false) ? 'foto' : 'video';

                // Simpan file
                $nama_file = $konten_file->getRandomName();
                $konten_file->move('assets/sosmed/konten', $nama_file);

                // Simpan ke database
                if (!$this->detailKontenModel->save([
                    'id_konten' => $id_konten,
                    'media' => $nama_file,
                    'tipe_media' => $tipe_media
                ])) {
                    $errors = $this->detailKontenModel->errors();
                    return redirect()->back()
                        ->with('error', 'Gagal menyimpan media.')
                        ->with('validation', $errors)
                        ->withInput();
                }
            }
        }


        return redirect()->to(route_to('konten'))->with('success', 'Konten sosial media berhasil ditambahkan.');
    }

    public function getByBisnis($id_bisnis)
    {
        $id_user = session()->get('id_user');
        $role = session()->get('role');

        if ($role === 'admin') {
            // Admin bisa melihat semua sosmed dari bisnis tersebut
            $sosmed = $this->sosmedModel
                ->where('id_bisnis', $id_bisnis)
                ->findAll();
        } else {
            // User hanya bisa melihat sosmed miliknya (melalui relasi)
            $idSosmedUser = $this->userSosmedModel->getSosmedIdsByUser($id_user);

            // Ambil sosmed dari bisnis tersebut yang juga dimiliki user
            if (!empty($idSosmedUser)) {
                $sosmed = $this->sosmedModel
                    ->where('id_bisnis', $id_bisnis)
                    ->whereIn('id_sosmed', $idSosmedUser)
                    ->findAll();
            } else {
                $sosmed = []; // tidak punya akses ke sosmed manapun
            }
        }

        return $this->response->setJSON($sosmed);
    }

    public function delete($id_konten)
    {
        $this->kontenModel->delete($id_konten);
        return redirect()->to(route_to('konten'))->with('success', 'Data berhasil dihapus.');
    }

    public function edit($id_konten)
    {
        $konten = $this->kontenModel->find($id_konten);

        if (!$konten) {
            throw new \CodeIgniter\Exceptions\PageNotFoundException("Konten dengan ID $id_konten tidak ditemukan.");
        }

        // Ambil data bisnis
        $allBisnis = $this->bisnisModel->findAll();

        // Ambil ID sosmed yang sudah dipilih (asumsikan disimpan dalam kolom id_sosmed sebagai string "1,3,4")
        $selectedSosmed = explode(',', $konten['id_sosmed'] ?? '');

        $data = [
            'konten' => $konten,
            'allBisnis' => $allBisnis,
            'selectedSosmed' => $selectedSosmed,
        ];

        return view('pages/konten_sosmed/edit', $data);
    }
}
